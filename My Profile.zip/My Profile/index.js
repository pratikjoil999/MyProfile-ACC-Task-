
/*********** author => pratik joil ***********/

const express = require('express')
var mysql = require('mysql')
const bodyParser = require('body-parser')
const app = express()
const port = 4000
app.use(express.static('./library'))
app.use(express.static('./node_modules'))
app.use(bodyParser.urlencoded({extended: false}))
app.set('view engine', 'ejs');
const {body, validationResult} = require('express-validator/check');



/**************** Redirect to form page (i.e index.ejs) *******************/
app.get('/', function (req, res) {
//  res.sendFile('index.html', { root: __dirname })
    res.render('index', { title: 'Data Saved',sucess:'',err:'' })
});

app.post('/',
[
  body('fname').isEmpty(),body('lname').isEmpty(),body('dob').isEmpty(),body('email').isEmpty(),body('contact').isEmpty(),



],
(req, res) => {
const errors = validationResult(req);


  if(errors.isEmpty() === true)
  {


        res.render('index', { title: 'Data Saved',sucess:'',err:'Enter Required * Data '})
        console.log('error');
  }

  else
  {





        /***********   Set MYSQL Connection     ***************/
          var connection = mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password: '',
            database: 'linkedin'
          })
        /*************** To Check MYSQL Connection ***********/
          connection.connect(function(err){
            if(err) throw err;
            console.log('Connected..');

          })

        /******************** To Print Fornm data In Console  *******************/
          console.log(req.body);

          var sql = "insert into profile values(null,'"+req.body.fname+"','"+req.body.mname+"','"+req.body.lname+"','"+req.body.dob+"','"+req.body.email+"','"+req.body.contact+"','"+req.body.industry+"','"+req.body.address+"','"+req.body.country+"','"+req.body.state+"','"+req.body.city+"','"+req.body.pin+"','"+req.body.about+"','"+req.body.website+"','"+req.body.git+"')";
          connection.query(sql, function (err) {
          if (err) throw err
          console.log('Data Sucessfully inserted');
        //  res.redirect('/');
          res.render('index', { title: 'Data Saved', sucess: 'Data Saved Sucessfully' ,err:''})

          })
          console.log('Data Sucessfully inserted');
          connection.end();



  }

}
);


app.listen(port, () => console.log(`Example app listening on port ${port}!`))
